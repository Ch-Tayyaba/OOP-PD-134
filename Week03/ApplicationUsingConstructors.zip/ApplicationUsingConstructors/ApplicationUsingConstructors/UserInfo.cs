﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationUsingConstructors
{
    class UserInfo
    {
        public string names;
        public string degree;
        public string totalMarks;
        public string obtMarks;
        public string fee;
    }
}
